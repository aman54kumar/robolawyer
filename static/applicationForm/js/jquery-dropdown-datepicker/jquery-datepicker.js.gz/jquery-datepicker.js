$(function(){
    $('.jsdatedropdown').dropdownDatepicker({
      allowFuture:false,
      dropdownClass: 'form-control form-control-inline',
      wrapperClass:'date-dropdowns',
      defaultDateFormat:'yyyy-mm-dd',
      displayFormat:'ymd',
      submitFormat:'dd/mm/yyyy',
      daySuffixes:false,
    });
  });