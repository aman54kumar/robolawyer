$(document).ready(function() {
  $('.datepicker').datepicker({
    weekStart: 1,
    assumeNearbyYear: true,
    autoclose: true,
    todayHighlight: true,
    clearBtn: true,
    todayHighlight: true,
    format: "dd-mm-yyyy"
  })
});
// function addDatepicker() {        
  
//   });
// }

// $('document').on('focus',".datepicker", function(){
//   $(this).addDatepicker();
// })