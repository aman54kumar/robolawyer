// function addDatepicker() {        
//   console.log("this triggered")
//   $('.datepicker').datepicker({
//     weekStart: 1,
//     assumeNearbyYear: true,
//     autoclose: true,
//     todayHighlight: true,
//     clearBtn: true,
//     todayHighlight: true,
//   });
// }

// $('document').on('focus',".datepicker", function(){
//   $(this).addDatepicker();
// })